﻿namespace CoreApplication;

public class OperationResultContainer
{
    public double Result {  get; set; }
    public string OperationDetail { get; set; } = default!;
}
