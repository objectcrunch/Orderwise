﻿namespace CoreApplication;

public class Options
{
    public int OperandSizeLimit {  get; set; }
}
